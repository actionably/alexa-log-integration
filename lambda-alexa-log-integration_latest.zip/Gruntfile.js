module.exports = function(grunt) {
  grunt.initConfig({
    lambda_package: {
      default: {
        options: {
          include_time: false,
          include_version: false
        }
      }
    },
    lambda_invoke: {
      default: {
        options: {
          file_name: './src/index.js',
          event: 'aws/test-event/test.json'
        }
      }
    }
  })

  grunt.loadNpmTasks('grunt-aws-lambda')

  grunt.registerTask('default', ['lambda_package'])
}
