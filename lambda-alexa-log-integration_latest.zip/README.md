# lambda-alexa-log-integration
Alexa integration that uses CloudWatch subscription to remove dashbot integration off the critical path.
