'use strict'
require('dotenv').config()

const errorUtil = require('error-util')
const handler = require('./handler')

exports.handler = (event, context, callback) => {
  errorUtil.handleLambda(handler.handle(event, context), event, context, callback)
}
