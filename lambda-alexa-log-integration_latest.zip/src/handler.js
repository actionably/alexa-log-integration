const path = require('path')
const debug = require('debug')(path.basename(__filename))
const zlib = require('zlib');
const dashbot = require('dashbot')(process.env.DASHBOT_API_KEY).alexa;
const _ = require('lodash')

class Handler {
  async handle(event, context) {
    const payload = Buffer.from(_.get(event, 'awslogs.data'), 'base64');
    zlib.gunzip(payload, (e, result) => {
      if (e) {
        throw new Error(e.toString())
      } else {
        result = JSON.parse(result.toString('ascii'));
        const message = _.get(result, 'logEvents.0.message');

        const messageJson = JSON.parse(message)
        const incoming = _.get(messageJson, 'incoming');
        const outgoing = _.get(messageJson, 'outgoing');

        if (incoming) {
          debug('incoming: ', JSON.stringify(incoming, null, 2))
          const incomingEvent = _.get(incoming, 'event')
          const incomingContext = _.get(incoming, 'context')

          dashbot.logIncoming(incomingEvent, incomingContext)
        }

        if (outgoing) {
          debug('outgoing: ', JSON.stringify(outgoing, null, 2))
          const outgoingEvent = _.get(outgoing, 'event')
          const outgoingResponse = _.get(outgoing, 'response')
          const outgoingContext = _.get(outgoing, 'context')

          dashbot.logOutgoing(outgoingEvent, outgoingResponse, outgoingContext)
        }

        context.succeed();
      }
    });
  }
}

module.exports = new Handler()

